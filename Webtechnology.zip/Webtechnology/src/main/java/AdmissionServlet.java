import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;

@WebServlet("/StudentAdmissionServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class AdmissionServlet extends HttpServlet {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String dob = request.getParameter("dob");
        
        Part passportPart = request.getPart("passport");
        String passportFileName = getFileName(passportPart);
        String passportContentType = passportPart.getContentType();
        
        Part certificatesPart = request.getPart("certificates");
        String certificatesFileName = getFileName(certificatesPart);
        String certificatesContentType = certificatesPart.getContentType();
        
        // Save files to the desired directory
        // You can implement your logic here
        
        // Dummy response for demonstration
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body style=\"margin-left: 20%; margin-right: 20%; background-color: white; color: black;\">");
        out.println("<fieldset style=\"height: 300px; width: 300px; margin-top: 100px; text-align: center; background-color: white; color: black; border-radius: 5px;\">");
        out.println("<h3 style=\"color: #2ecc71;\">Student Details:</h3>");
        out.println("Name: " + name + "<br><br>");
        out.println("Date of Birth: " + dob + "<br><br>");
        out.println("Passport Picture: " + passportFileName + " (" + passportContentType + ")<br><br>");
        out.println("Certificates: " + certificatesFileName + " (" + certificatesContentType + ")<br><br>");
        out.println("<a href=\"success.jsp\" style=\"text-decoration: none; width: 100%; padding: 10px; margin-top: 10px; background-color: white; color: black; border: 1px solid black; border-radius: 5px; cursor: pointer;\"> Save</a>");
        out.println("</fieldset></body></html>");

    }
    
    private String getFileName(final Part part) {
        final String partHeader = part.getHeader("content-disposition");
        for (String content : partHeader.split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }
}
